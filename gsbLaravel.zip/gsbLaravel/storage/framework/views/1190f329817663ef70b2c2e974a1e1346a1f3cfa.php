<div class="message">
    <ul>
          <li> <?php echo e($message); ?></li>
    </ul>
    </div><?php /**PATH D:\Logiciels\laragon\www\gsbLaravel\resources\views/message.blade.php ENDPATH**/ ?>