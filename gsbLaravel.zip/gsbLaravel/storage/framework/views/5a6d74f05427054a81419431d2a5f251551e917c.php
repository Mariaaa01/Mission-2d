
<?php $__env->startSection('contenu1'); ?>

<div id="contenu">
<h2>Fiche frais validées a mettre en paiement</h2>
    <form method="post"  action="<?php echo e(route('chemin_sauvegardeFraisC')); ?>">
                    <?php echo e(csrf_field()); ?> <!-- laravel va ajouter un champ caché avec un token -->
        <div>
            <table>
                <tr>
                    <th>Visiteur</th>
                    <th>Mois</th>
                    <th>Montant</th>
                    <th>Date de modification</th>
                </tr>
                <?php $__currentLoopData = $lesFrais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unFrais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
			    <td> <?php echo e($unFrais['idVisiteur']); ?> </td>
                <td> <?php echo e($unFrais['mois']); ?> </td>
                <td> <?php echo e($unFrais['montantValide']); ?> </td>
                <td> <?php echo e($unFrais['dateModif']); ?> </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <div class="piedForm">
            <p>
            <input id="ok" type="submit" value="Valider" size="20" />
            <input id="annuler" type="reset" value="Annuler" size="20" />
            </p> 
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sommaireC', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Logiciels\laragon\www\gsbLaravel\resources\views/majFraisForfaitC.blade.php ENDPATH**/ ?>