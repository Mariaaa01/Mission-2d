
<?php $__env->startSection('contenu1'); ?>

<div id="contenu">
<h2>Fiche frais validées a mettre en paiement</h2>
        <div>
          <p>Les fiches ont été remboursées.</p>  
         </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sommaireC', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\gsbLaravel\resources\views/ficherb.blade.php ENDPATH**/ ?>