
    <?php $__env->startSection('menu'); ?>
            <!-- Division pour le sommaire -->
        <div id="menuGauche">
            <div id="infosUtil">
                  
             </div>  
               <ul id="menuList">
                   <li >
                    <strong>Bonjour <?php echo e($comptable['nom'] . ' ' . $comptable['prenom']); ?> le comptable</strong>
                      
                   </li>
                   </li>
                  <li class="smenu">
                     <a href="<?php echo e(route('chemin_gestionFraisC')); ?>" title="Suivie du paiement fiche frais ">Suivie du paiement fiche frais</a>
                  </li>
                  <!--<li class="smenu">
                    <a href="<?php echo e(route('chemin_selectionMois')); ?>" title="Editer fiche à mettre en paiement du mois">Editer fiche à mettre en paiement du mois</a>
                  </li>-->
               <li class="smenu">
                <a href="<?php echo e(route('chemin_deconnexion')); ?>" title="Se déconnecter">Déconnexion</a>
                  </li>
                </ul>
               
        </div>
    <?php $__env->stopSection(); ?>          
<?php echo $__env->make('modeles/visiteur', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Logiciels\laragon\www\gsbLaravel\resources\views/sommaireC.blade.php ENDPATH**/ ?>