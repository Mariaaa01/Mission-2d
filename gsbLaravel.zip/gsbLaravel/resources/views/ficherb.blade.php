@extends ('sommaireC')
@section('contenu1')

<div id="contenu">
<h2>Fiche frais validées a mettre en paiement</h2>
        <div>
          <p>Les fiches ont été remboursées.</p>  
         </div>
@endsection