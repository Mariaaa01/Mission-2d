@extends ('modeles/visiteur')
    @section('menu')
            <!-- Division pour le sommaire -->
        <div id="menuGauche">
            <div id="infosUtil">
                  
             </div>  
               <ul id="menuList">
                   <li >
                    <strong>Bonjour {{ $comptable['nom'] . ' ' . $comptable['prenom'] }} le comptable</strong>
                      
                   </li>
                   </li>
                  <li class="smenu">
                     <a href="{{ route('chemin_gestionFraisC')}}" title="Suivie du paiement fiche frais ">Suivie du paiement fiche frais</a>
                  </li>
                  <li class="smenu">
                    <a href="{{ route('chemin_selectionMois') }}" title="Editer fiche à mettre en paiement du mois">Editer fiche à mettre en paiement du mois</a>
                  </li>
               <li class="smenu">
                <a href="{{ route('chemin_deconnexion') }}" title="Se déconnecter">Déconnexion</a>
                  </li>
                </ul>
               
        </div>
    @endsection          