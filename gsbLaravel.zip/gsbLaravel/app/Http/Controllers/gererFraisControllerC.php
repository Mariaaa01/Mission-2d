<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use PdoGsb;
use MyDate;
class gererFraisControllerC extends Controller{

    function listerFrais(Request $request){
        if( session('visiteur') != null){
            $visiteur = session('visiteur');
            $lesFrais=PdoGsb::getLesFrais();

            $view = view('majFraisForfaitC')
                    ->with('erreurs',null)
                    ->with('lesFrais', $lesFrais)
                    ->with('comptable',$visiteur);
            return $view;
        }
        
        else{
            return view('connexion')->with('erreurs',null);
        }
    }
    function updateFraisC(Request $request){
        if( session('visiteur') != null){
            $visiteur = session('visiteur');
            $lesFrais=PdoGsb::getLesFrais();
            foreach($lesFrais as $unFrais)
            {
               PdoGsb::updateFrais($unFrais['idVisiteur'],$unFrais['mois']);
            }
            $view = view('ficherb')
                    ->with('erreurs',null)
                    ->with('comptable',$visiteur);
            return $view;
        }
        else{
            return view('connexion')->with('erreurs',null);
        }
    }
    
}














